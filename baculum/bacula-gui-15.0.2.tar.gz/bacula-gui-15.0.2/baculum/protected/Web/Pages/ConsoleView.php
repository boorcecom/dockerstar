<?php
/*
 * Bacula(R) - The Network Backup Solution
 * Baculum   - Bacula web interface
 *
 * Copyright (C) 2013-2021 Kern Sibbald
 *
 * The main author of Baculum is Marcin Haba.
 * The original author of Bacula is Kern Sibbald, with contributions
 * from many others, a complete list can be found in the file AUTHORS.
 *
 * You may use this file and others of this release according to the
 * license defined in the LICENSE file, which includes the Affero General
 * Public License, v3.0 ("AGPLv3") and some additional permissions and
 * terms pursuant to its AGPLv3 Section 7.
 *
 * This notice must be preserved when any source code is
 * conveyed and/or propagated.
 *
 * Bacula(R) is a registered trademark of Kern Sibbald.
 */

use Baculum\Web\Modules\BaculumWebPage;

/**
 * Console view page.
 *
 * @author Marcin Haba <marcin.haba@bacula.pl>
 * @category Page
 * @package Baculum Web
 */
class ConsoleView extends BaculumWebPage {

	public function onInit($param) {
		parent::onInit($param);
		if ($this->IsCallBack || $this->IsPostBack) {
			return;
		}
		/**
		 * NOTE: component name is not used here, set only for compatibility
		 * with BaculaConfigDirectives.
		 */
		$this->ConsoleResourcesConfig->setComponentName($_SESSION['director']);
	}

	public function loadConsoleResourcesConfig($sender, $param) {
		$resource_type = $param->getCallbackParameter();
		if (!empty($resource_type)) {
			$this->ConsoleResourcesConfig->setResourceType($resource_type);
			$this->ConsoleResourcesConfig->loadResourceListTable();
		} else {
			$this->ConsoleResourcesConfig->showError(true);
		}
	}
}
?>
